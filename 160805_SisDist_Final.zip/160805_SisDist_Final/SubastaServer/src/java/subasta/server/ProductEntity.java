package subasta.server;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import subasta.common.Product;

@Entity
public class ProductEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "nombre")
    private String nombre;
    
    @Column(name = "precInit")
    private Float precInit;
    
    @Column(name = "precFinal")
    private Float precFinal;
    
    @Column(name = "vendedor")
    private String vendedor;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return nombre;
    }

    public void setName(String name) {
        this.nombre = nombre;
    }

    public Float getInitPrice() {
        return precInit;
    }

    public void setInitPrice(Float initPrice) {
        this.precInit = precInit;
    }

    public Float getEndPrice() {
        return precFinal;
    }

    public void setEndPrice(Float endPrice) {
        this.precFinal = precFinal;
    }

    public String getSeller() {
        return vendedor;
    }

    public void setSeller(String seller) {
        this.vendedor = vendedor;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductEntity)) {
            return false;
        }
        ProductEntity other = (ProductEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    public static ProductEntity toEntity(Product prod) {
        ProductEntity toret = new ProductEntity();
        toret.setName(prod.getName());
        toret.setInitPrice(prod.getInitialPrice());
        toret.setEndPrice(prod.getCurrentPrice());
        toret.setSeller(prod.getSeller());
        return toret;
    }

    @Override
    public String toString() {
        return String.format("%-5d %-5s %-10.2f %-10.2f %s",
                id,
                nombre,
                precInit,
                precFinal,
                vendedor
        );
    };
}
