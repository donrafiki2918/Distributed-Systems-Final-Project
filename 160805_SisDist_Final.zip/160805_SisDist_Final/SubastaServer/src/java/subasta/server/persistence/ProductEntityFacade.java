/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.server.persistence;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import subasta.server.ProductEntity;

@Stateless
public class ProductEntityFacade extends AbstractFacade<ProductEntity> implements ProductEntityFacadeLocal {

    @PersistenceContext(unitName = "SubastaServerPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductEntityFacade() {
        super(ProductEntity.class);
    }
    
}
