
package subasta.server;

import javax.ejb.Stateless;

import java.rmi.RemoteException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import subasta.common.Bid;
import subasta.common.Controller;
import subasta.common.Product;
import subasta.common.User;
import subasta.server.persistence.ProductEntityFacadeLocal;


@Stateless(name = "subastaserver")
public class AuctionServer implements AuctionServerRemote {

    Hashtable<String, User> users = new Hashtable<>();
    Hashtable<String, Product> products = new Hashtable<>(); 
    List<Bid> bidHistory = new ArrayList<>(); 
    @EJB
    private ProductEntityFacadeLocal productFacade;
    
    @Override
    public boolean registerUser(String name, User client) {
        if (!users.containsKey(name)) { 

            System.out.println("Adding new user: " + name);
            users.put(name, client);
            return true;

        } else

            return false;
    }

    @Override
    public boolean userExists(String number) {
        return users.containsKey(number);
    }

    @Override
    public boolean addProductToAuction(String user, final String product, final Product offer) {
        
        if (!products.containsKey(product)) {

            System.out.println("Adding product: " + product);
            products.put(product, offer); 
            productFacade.create(ProductEntity.toEntity(offer));
            bidHistory.add(new Bid(user, product, offer.getInitialPrice()));

            ZoneId znid = ZoneId.systemDefault(); 
            LocalDateTime end = offer.getClosingDate(); 
            Instant endTime = end.atZone(znid).toInstant(); 
            long startTime = Instant.now().toEpochMilli();
            long durationSecond = endTime.minusMillis(startTime).toEpochMilli();

            final Timer timer = new Timer(); 
           
            TimerTask task = new TimerTask() {
                @Override
                public void run() {

                    System.out.println("Auction of " + product + " ended!");
                    
                    offer.setActive(false);
                    
                    System.out.println("La persona " + offer.getSeller() + " ha ganado el producto:\n" + offer);
                   
                    timer.cancel();
                    timer.purge();

                }
            };

            timer.schedule(task, durationSecond, 1000);

            return true;

        } else
            return false;
    }

    @Override
    public boolean productExists(String product) {
        return products.containsKey(product);
    }

    @Override
    public boolean addOffer(String buyer, String product, float amount) {
        if (products.containsKey(product)) { 

            Product infoProd = products.get(product); 
            User user = users.get(buyer);

            if (infoProd.updatePrice(amount, user.getName())) { 

                bidHistory.add(new Bid(user.getName(), infoProd.getName(), infoProd.getCurrentPrice())); 
                System.out.println("Producto " + infoProd.getName() + " puesto en venta");
                return true;

            } else
                return false; 

        } else
            return false; 
    }

    @Override
    public List<Product> getCatalog() {
        List<Product> toRet = new ArrayList<>();
        for(Product curr : products.values()) {
            if(curr.isActive()){
                toRet.add(curr);
            }
        }
        return toRet;
    }

    @Override
    public List<Bid> getBidHistory() {
        List<Bid> sorted = new ArrayList<>(bidHistory);
        
        Collections.sort(sorted, new Comparator<Bid>() {
            @Override
            public int compare(Bid b1, Bid b2) {
                int prdCmp = b1.getProduct().compareTo(b2.getProduct());
                if(prdCmp != 0) {
                    return prdCmp;
                }
                return Float.compare(b1.getPrice(), b2.getPrice());
            }
        });
        return sorted; 
    }
    
    
    
}
