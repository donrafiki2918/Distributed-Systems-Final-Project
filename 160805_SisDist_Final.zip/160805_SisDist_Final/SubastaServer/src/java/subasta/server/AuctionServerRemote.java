/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.server;

import java.util.List;
import javax.ejb.Remote;
import subasta.common.Bid;
import subasta.common.Controller;
import subasta.common.Product;
import subasta.common.User;

@Remote
public interface AuctionServerRemote {

    boolean registerUser(String name, User client);

    boolean userExists(String number);

    boolean addProductToAuction(String user, String product, Product offer);

    boolean productExists(String product);

    boolean addOffer(String buyer, String product, float amount);

    List<Product> getCatalog();

    List<Bid> getBidHistory();
    
}
