/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.connect;

import java.util.Properties;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ConnectionEJB {
    static final Properties props = new Properties();
    static InitialContext ic = null;
    
    static {
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");
        
        try{
            ic = new InitialContext(props);
        }
        catch(NamingException ex) {
            ex.printStackTrace();
        }
    }
    
    public static Object getEJBRemote(String nameEJB) throws NamingException {
        return ic.lookup(nameEJB);
    }
    
}
