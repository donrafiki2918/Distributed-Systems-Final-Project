package subasta.client;

import subasta.common.Product;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.time.LocalDateTime;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class Client {

    private AuctionController controller;

    private JFrame mainFrame;

    private JTextField userField;
    private JTextField directionField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField nicknameField;
    private JPanel userPanel;

    private JTextField productField;
    private JTextField descriptionField;
    private JTextField priceField;
    private JTextField yearField;
    private JTextField monthField;
    private JTextField dayField;
    private JTextField hourField;
    private JTextField minuteField;
    private JPanel productPanel;
    private JTextField amountField;

    private DefaultListModel<Product> products;
    private JTextArea descriptionText;
    private JList list;
    private JButton connect;
    private JButton exit;
    private JButton putOnSale;
    private JButton makeBid;
    private JButton getList;

    private static final Font FONT = new Font("Arial", Font.BOLD, 14);

    public Client() {

        //Try to initialize Controller
        try {
            controller = new AuctionController(this);
        } catch (RemoteException ex) {
            ex.printStackTrace();
            System.exit(1);
        }
        catch(NullPointerException ex) {
            System.exit(1);
        }

        Container panel;

        mainFrame = new JFrame("Cliente Subasta"); 
        panel = mainFrame.getContentPane();
        panel.setLayout(new BorderLayout());

        //Header panel
        JPanel north = new JPanel();
        north.setLayout(new BorderLayout());
        JPanel userData = new JPanel(); 
        userData.setLayout(new GridLayout(1, 2));
        JPanel userActions = new JPanel();
        userActions.setLayout(new GridLayout(0, 1));

        userField = new JTextField();
        userData.add(new JLabel("Nombre del usuario:"));
        userData.add(userField);

        connect = new JButton("Conectar");
        userActions.add(connect);
        putOnSale = new JButton("Poner a la venta");
        userActions.add(putOnSale);
        putOnSale.setEnabled(false);
        getList = new JButton("Actualizar ofertas");
        userActions.add(getList);

        north.add(userData, BorderLayout.NORTH);
        north.add(userActions, BorderLayout.SOUTH);
        panel.add(north, BorderLayout.NORTH);

        products = new DefaultListModel<>();
        list = new JList(products); // data has type Object[]
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setLayoutOrientation(JList.VERTICAL);
        list.setFont(FONT);
        JScrollPane scrollList = new JScrollPane(list);
        scrollList.setPreferredSize(new Dimension(250, 80));
        panel.add(scrollList, BorderLayout.CENTER);

        JPanel south = new JPanel();
        south.setLayout(new BorderLayout());
        JPanel prodInfoPanel = new JPanel();
        prodInfoPanel.setLayout(new GridLayout(1, 2));
        JPanel offerPanel = new JPanel();
        offerPanel.setLayout(new GridLayout(1, 2));

        JLabel descLabel = new JLabel("Descripcion: ");
        prodInfoPanel.add(descLabel);
        descriptionText = new JTextArea();
        JScrollPane scrollDescription = new JScrollPane(descriptionText);
        descriptionText.setEditable(false);
        descriptionText.setLineWrap(true);
        descriptionText.setWrapStyleWord(true);
        scrollDescription.setPreferredSize(new Dimension(mainFrame.getWidth(), 30));

        prodInfoPanel.add(scrollDescription);
        south.add(prodInfoPanel, BorderLayout.NORTH);

        amountField = new JTextField();
        makeBid = new JButton("Ofrecer");
        offerPanel.add(makeBid);
        makeBid.setEnabled(false);
        offerPanel.add(amountField);
        south.add(offerPanel, BorderLayout.CENTER);

        exit = new JButton("Salir");
        south.add(exit, BorderLayout.SOUTH);
        panel.add(south, BorderLayout.SOUTH);

        createUserPanel();
        createProductPanel();
        initializeListeners();

        mainFrame.setSize(600, 500);
        mainFrame.setMinimumSize(new Dimension(600, 500));
        mainFrame.setVisible(true);
        mainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApp();
            }
        });

    }

    private void createUserPanel() {
        userPanel = new JPanel();
        userPanel.setLayout(new GridLayout(0, 2));
        directionField = new JTextField();
        userPanel.add(new JLabel("Direccion:"));
        userPanel.add(directionField);
        emailField = new JTextField();
        userPanel.add(new JLabel("Correo:"));
        userPanel.add(emailField);
        phoneField = new JTextField();
        userPanel.add(new JLabel("Telefono:"));
        userPanel.add(phoneField);
        nicknameField = new JTextField();
        userPanel.add(new JLabel("Nickname:"));
        userPanel.add(nicknameField);

        userPanel.setPreferredSize(new Dimension(300, 150));
    }

 
    private void createProductPanel() {

        productPanel = new JPanel();
        productPanel.setLayout(new GridLayout(0, 2)); 
        productField = new JTextField(); 
        productPanel.add(new JLabel("Nombre:"));
        productPanel.add(productField); 
        priceField = new JTextField(); 
        productPanel.add(new JLabel("Precio inicial:"));
        productPanel.add(priceField); 
        descriptionField = new JTextField(); 
        productPanel.add(new JLabel("Descripcion:"));
        productPanel.add(descriptionField); 
        productPanel.add(new JLabel("Fecha de Cierre"));
        productPanel.add(new JLabel("")); 

        yearField = new JTextField();
        productPanel.add(new JLabel("Año:"));
        productPanel.add(yearField);
        monthField = new JTextField();
        productPanel.add(new JLabel("Mes (1 a 12):"));
        productPanel.add(monthField);
        dayField = new JTextField();
        productPanel.add(new JLabel("Dia (1 a 31):"));
        productPanel.add(dayField);

        productPanel.add(new JLabel("Tiempo de Cierre"));
        productPanel.add(new JLabel(""));//Empty label to fill grid

        hourField = new JTextField();
        productPanel.add(new JLabel("Hora (0 a 23):"));
        productPanel.add(hourField);
        minuteField = new JTextField();
        productPanel.add(new JLabel("Minutos (0 a 59):"));
        productPanel.add(minuteField);

        productPanel.setPreferredSize(new Dimension(350, 500));
    }

  
    private void initializeListeners() {

        connect.addActionListener(e -> controller.connectUser() ); 

        exit.addActionListener(e -> exitApp()); 

        //Put on sale action perform
        putOnSale.addActionListener(e -> {
            try {
                controller.putOnSale(); 
            } catch (RemoteException ex) {
                System.out.println("Error al poner en venta un name");
            }
        });

        makeBid.addActionListener(e -> {
            try {
                controller.offerOnProduct(); 
            } catch (RemoteException ex) {
                System.out.println("Error al makeBid en name");
            }
        });
        
        getList.addActionListener(e -> {
            try {
                controller.updateView();
            }
            catch(RemoteException ex) {
                JOptionPane.showMessageDialog(null,
                    "Surgio un problema al actualizar la interfaz, intente de nuevo.",
                    "Actualizar interfaz",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        list.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting() == false) {
                    JList list = (JList) e.getSource(); 
                    Product item = (Product) list.getSelectedValue(); 
                    controller.changeDescription(item); 
                    
                }
            }
        });
    }


    private void exitApp() {

        controller.disconnect(); 
        System.exit(0); 

    }

  
    public void activateButtons() {
        makeBid.setEnabled(true); 
        putOnSale.setEnabled(true);
        connect.setEnabled(false); 
    }

  
    public JPanel getUserPanel() {
        return userPanel;
    }

 
    public String getCurrentUser() throws IllegalArgumentException {
        String txt = userField.getText();

        if(txt.length() == 0)
            throw new IllegalArgumentException("Usuario no puede estar vacío, intente otra vez.");


        return txt;
    }


    public String getDirection() throws IllegalArgumentException {
        String txt = directionField.getText();

        if(txt.length() == 0)
            throw new IllegalArgumentException("Direccion no puede estar vacía, intente otra vez.");


        return txt;
    }


    public String getEmail() throws IllegalArgumentException {
        String txt = emailField.getText();

        if(txt.length() == 0) throw new IllegalArgumentException("Correo no puede estar vacío, intente otra vez.");


        String emailTest = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

        boolean pass = txt.matches(emailTest);

        if (!pass) throw new IllegalArgumentException("Texto introducido no es un correo valido, intente otra vez.");


        return txt;
    }


    public String getPhone() throws IllegalArgumentException {
        String txt = phoneField.getText();

        if(txt.length() == 0) throw new IllegalArgumentException("Telefono no puede estar vacío, intente otra vez.");

        if(txt.length() > 10) throw new IllegalArgumentException("Numero de phone no puede ser mayor a 10 digitos");

        String resultado = "";
        long phone = Long.parseLong(txt); 
        resultado = String.valueOf(phone);


        return resultado;
    }

String getNickname() throws IllegalArgumentException {
        String txt = nicknameField.getText();

        if(txt.length() == 0) throw new IllegalArgumentException("Nickname no puede estar vacío, intente otra vez.");

        return txt;
    }


    public void resetUserPanel() {
        directionField.setText("");
        emailField.setText("");
        phoneField.setText("");
        nicknameField.setText("");
    }


    public JPanel getProductPanel() {
        return productPanel;
    }


    public String getProductName() {
        return productField.getText();
    }

    public String getProductDescription() throws IllegalArgumentException {
        String txt = descriptionField.getText(); 

        if(txt.length() == 0) throw new IllegalArgumentException("La descripción no puede estar vacía, intente otra vez.");

        if(txt.length() > 20) throw new IllegalArgumentException("La descripción del producto no puede ser mayor a 30 digitos");

        return txt;
    }


    public float getProductPrice() throws IllegalArgumentException {
        String txt = priceField.getText();

        if(txt.length() == 0) throw new IllegalArgumentException("Precio no puede estar vacío, intente otra vez.");

        float resultado = 0;
        resultado = Float.parseFloat(txt);
        if (resultado < 0) throw new IllegalArgumentException("Precio no puede ser menor a 0, intente otra vez.");


        return resultado;
    }


    public int getOfferYear() throws IllegalArgumentException {
        String txt = yearField.getText();

        if(txt.length() == 0) throw new IllegalArgumentException("Año no puede estar vacío, intente otra vez.");

        int resultado = 0;
        resultado = Integer.parseInt(txt); 

        if (resultado < LocalDateTime.now().getYear())
            throw new IllegalArgumentException("Año no puede ser anterior al actual.");

 
        return resultado;
    }


    public int getOfferMonth() throws IllegalArgumentException {
        String txt = monthField.getText(); //Gets text from monthField
        //If field was left empty throw a new exception since this field cannot be left empty
        if(txt.length() == 0) throw new IllegalArgumentException("Mes no puede estar vacío, intente otra vez.");

        int resultado = 0;
        resultado = Integer.parseInt(txt); //Tries to parse to integer text from monthField
        //If value isn't between 0 and 12, throws new exception
        if (resultado < 0 || resultado > 12) throw new IllegalArgumentException("Mes debe estar entre 0 y 12");

        //If parsing was made without any error, return parsed value
        return resultado;
    }

   
    public int getOfferDay() throws IllegalArgumentException {
        String txt = dayField.getText(); //Retrieves text from dayField
        //If field was left empty throw a new exception since this field cannot be left empty
        if(txt.length() == 0) throw new IllegalArgumentException("Dia no puede estar vacío, intente otra vez.");

        int resultado = 0;
        resultado = Integer.parseInt(txt); //Tries to parse to integer text from dayField
        //If value isn't between 0 and 31, throws new exception.
        if (resultado < 0 || resultado > 31) throw new IllegalArgumentException("Dia debe de estar entre 0 y 31.");

        //If parsing was made without any error, return parsed value
        return resultado;
    }


    public int getOfferHour() throws IllegalArgumentException {
        String txt = hourField.getText(); //Gets text from hourField
        //If field was left empty throw a new exception since this field cannot be left empty
        if(txt.length() == 0) throw new IllegalArgumentException("Hora no puede estar vacia, intente otra vez.");

        int resultado = 0;
        resultado = Integer.parseInt(txt); //Tries to parse to integer text from hourField
        //If parsed value is not between 0 and 23, throws new exception
        if (resultado < 0 || resultado > 24) throw new IllegalArgumentException("Hora debe estar entre 0 y 23.");

        //If parsing was made without any error, return parsed value
        return resultado;
    }


    public int getOfferMinutes() throws IllegalArgumentException {
        String txt = minuteField.getText(); //Gets text from minuteField
        //If field was left empty throw a new exception since this field cannot be left empty
        if(txt.length() == 0) throw new IllegalArgumentException("Minutos no pueden estar vacíos, intente otra vez.");

        int resultado = 0;
        resultado = Integer.parseInt(txt); //Tries to parse to integer text from minuteField
        //If input text is not between 0 and 59, throws exception
        if (resultado < 0 || resultado > 60) throw new IllegalArgumentException("Minutos deben de estar entre 0 y 59.");

        //If parsing was done without any errors, return text parsed.
        return resultado;
    }

    public void resetProductPanel() {
        productField.setText(""); //Set product's name field as empty
        descriptionField.setText(""); //Set product's description field as empty
        priceField.setText(""); //Set product's price field as empty
        yearField.setText(""); //Set product's ending date year field as empty
        monthField.setText(""); //Set product's ending date month field as empty
        dayField.setText(""); //Set product's ending date day field as empty
        hourField.setText(""); //Set product's ending time hour field as empty
        minuteField.setText(""); //Set product's ending time minutes field as empty
    }

c void resetProductList() {

        products.removeAllElements(); //Remove all elements from List Model
        descriptionText.setText(""); //Sets description text as empty

    }


    public void addProduct(Product prod) {

        products.addElement(prod); //Adds element to List Model

    }


    public void showDescription(String context) {

        descriptionText.setText(context); //Sets description text as received String

    }

   
    public float getAmountBid() throws IllegalArgumentException {
        String txt = amountField.getText(); //Retrieve text from amountField
        
        if(txt.length() == 0) throw new IllegalArgumentException("Campo no puede estar vacío, intente otra vez.");

        float resultado = 0.0f;
        resultado = Float.parseFloat(txt); 
   
        if (resultado < 0) throw new IllegalArgumentException("Precio no puede ser menor a 0, intente otra vez.");


        return resultado;
    }

   
    public Product getSelectedProduct() {

        return (Product) list.getSelectedValue();
    }
    
    public static void main(String... args) {
        new Client();
    }
}
