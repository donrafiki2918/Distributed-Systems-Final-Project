/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Bid {

    private String comprador;
    private String producto;
    private float precio;
    private LocalDateTime fecha;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    public Bid(String c, String p, float pr) {

        comprador = c;
        producto = p;
        precio = pr;
        fecha = LocalDateTime.now();

    }

    public String getProduct() {
        return producto;
    }

    public float getPrice() {
        return precio;
    }

    public String toString() {
        return String.format("%s, %.2f, %s %s",
                producto,
                precio,
                comprador,
                fecha.format(FORMATTER) );
    }

}