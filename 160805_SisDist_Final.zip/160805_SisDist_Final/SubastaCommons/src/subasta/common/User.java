/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.common;

import java.io.Serializable;


public class User implements Serializable {

    private String nombre;
    private String direccion;
    private String email;
    private String telefono;
    private String alias;

    public User(String n, String d, String e, String p, String nn) {
        this.nombre = n;
        this.direccion = d;
        this.email = e;
        this.telefono = p;
        this.alias = nn;
    }

    
    public String getName() {
        return nombre;
    }

    @Override
    public String toString() {
        return String.format("%s\n%s\n%s\n%s\n%s", nombre, direccion, email, telefono, alias);
    }

}
