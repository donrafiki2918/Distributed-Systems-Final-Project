/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subasta.common;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Product implements Serializable {

    private String vendedor;
    private String lastBidder;
    private String nombre;
    private String descripcion;
    private float precioInicial;
    private float precioReciente;
    private LocalDateTime fechaCierre;
    private boolean isActive;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

   
    public Product(String s, String n, String d, float price, LocalDateTime cd ) {

        vendedor = s;
        lastBidder = s;
        nombre = n;
        descripcion = d;
        precioInicial = price;
        precioReciente = price;
        fechaCierre = cd;
        isActive = true;

    }

    public boolean updatePrice(float amount, String user ) {

        if( amount > precioReciente) { 
            precioReciente = amount;
            lastBidder = user;
            return true;
        } else
            return false;
    }

   
    public String getSeller() {
        return vendedor;
    }

    
    public String getLastBidder() {
        return lastBidder;
    }

    
    public String getName() {
        return nombre;
    }

   
    public String getDescription() {
        return descripcion;
    }

    
    public float getInitialPrice() {
        return precioInicial;
    }

   
    public float getCurrentPrice() {
        return precioReciente;
    }

    public LocalDateTime getClosingDate() {
        return fechaCierre;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean status) {
        this.isActive = status;
    }

    @Override
    public String toString() {
        return String.format("%-10s Precio: %-10.2f Por: %-10s Fecha limite: %s",
                nombre,
                precioReciente,
                lastBidder,
                fechaCierre.format(FORMATTER)
        );
    }
}
